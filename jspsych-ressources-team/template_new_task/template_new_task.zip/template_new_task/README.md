# PDS New Task Template

This depository is a template depository to use in order to create a new task.
It can be used in conjonction with the experiment construction toolkit.

